# Decompiled BO4 GSC/CSC Scripts
This is a repository containing my best attempt at decompiling the scripts for BO4\
\
T8 (BO4) is a pain in that pretty much everything is hashed (more than t7). This means that a lot of the filenames are unknown\
I was able to make educated guesses on a lot of them, though, so we do have *some* file structure
# Why
Some stuff recently got leaked that will allow people to more easily achieve this, and I've had these decompiled for many months,\
so id rather release it ahead of time since there are a few other people who would do it anyways

# Special Thanks
Taleb - resources\
SyGnUs - string decryption help\
alexisloic21 - Found and reported a bug with for loops\
Kenshin9977 - Additional hashes\
Scobalula - Original T7 decompiler
